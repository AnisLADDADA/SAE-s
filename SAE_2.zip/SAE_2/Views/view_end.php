	<script src="Content/js/bootstrap.bundle.min.js"></script>
    <script src="Content/js/bootstrap.min.js"></script>
    <script src="Content/js/animath.js"></script>
    </body>
</html>
