<?php

$dsn = 'pgsql:host=localhost;port=5432;dbname=so';
$login = 'postgres';
$mdp = 'postgres';
?>
