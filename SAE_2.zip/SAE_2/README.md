# SAE Salon Culture & Jeux Mathématiques

Ce projet consiste à créer un site internet permettant de gérer un événement annuel proposant des activités mathématiques.

