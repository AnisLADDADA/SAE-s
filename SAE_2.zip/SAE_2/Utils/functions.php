<?php

function e($message)
{
    return htmlspecialchars($message, ENT_QUOTES);
}

