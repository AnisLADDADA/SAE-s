<?php 
$dsn = 'mysql:host=localhost;port=8889;dbname=equipe4_database;charset=utf8';
$login = 'root';
$mdp = 'root';
?>