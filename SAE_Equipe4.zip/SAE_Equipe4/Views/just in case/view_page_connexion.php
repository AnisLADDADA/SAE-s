
<?php 
$title = "Page D'accueil";
$nom_fichier_css = "connexion.css";
?>
<?php include ("include/connect_db.php");?>

<?php require "view_begin_html.php";?>

<header>
            <h1>Bienvenue sur le site de dépot du stage </h1>
        </header>

        <div class="login">
            <h2>Connexion</h2>
            <form  method="post">
                <div class="user">
                <input type="text" name="username" id="usr" required=""/>
                    
                    <label>Nom D'utilisateur</label>
                </div>

                <div class="user">
                    <input type="password" name="" id="pwd" required=""/>
                    <label for="">Mot De Passe</label>
                </div>
                <button type="submit" class="send" >


                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    submit
                </button>
            </form>
        </div>



<?php require "view_end_html.php";?>